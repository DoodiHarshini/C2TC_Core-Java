package com.cg.placementmanagement.repository;

import com.cg.placementmanagement.entity.User;

public interface IUserRepository {
	public User addUser(User user);
	public User updateUser(User user);
	public User deleteUser(int id);
	public boolean logOut();
	public abstract void commitTransaction();
	public abstract void beginTransaction();
}
