package com.cg.placementmanagement.service;

import com.cg.placementmanagement.entity.College;

public interface ICollegeService {
	public College addCollege(College college);
	public College updateCollege(College college);
	public College searchCollege(int id);
	public boolean deleteCollege(String college);
	public boolean schedulePlacement(String placement);

}
