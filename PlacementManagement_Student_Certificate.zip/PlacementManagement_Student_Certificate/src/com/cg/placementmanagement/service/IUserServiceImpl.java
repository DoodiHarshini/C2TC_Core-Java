package com.cg.placementmanagement.service;

import com.cg.placementmanagement.entity.User;
import com.cg.placementmanagement.repository.IUserRepository;
import com.cg.placementmanagement.repository.IUserRepositoryImpl;

public class IUserServiceImpl implements IUserService{
	private IUserRepository dao;

	public IUserServiceImpl()
	{
		dao=new IUserRepositoryImpl();
	}

	@Override
	public User addUser(User user) {
		dao.beginTransaction();
		dao.addUser(user);
		dao.commitTransaction();
		return user;
	}

	@Override
	public User updateUser(User user) {
		dao.beginTransaction();
		dao.updateUser(user);
		dao.commitTransaction();
		return user;
	}

	@Override
	public User login(User user) {
		dao.beginTransaction();
		dao.addUser(user);
		dao.commitTransaction();
		return user;
	}

	@Override
	public boolean logOut() {
		dao.beginTransaction();
		dao.logOut();
		dao.commitTransaction();
		return false;
	}
	

}
