package com.cg.placementmanagement.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="college")
public class College implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	private String collegeName;
	private String location;
	@OneToMany(mappedBy="college",cascade=CascadeType.ALL)
	private Student student;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id")
      private User user;
	@OneToMany(mappedBy="placement",cascade=CascadeType.ALL)
	private Placement placement;
	@OneToMany(mappedBy="college",cascade=CascadeType.ALL)
	private Certificate certificate;
	private Set<Student>students =new HashSet<>();
	public int getId() {
		return id;
	}
public void setId(int id) {
		this.id = id;
	}
	public String getCollegeName() {
		return collegeName;
	}
public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
public String getLocation() {
		return location;
	}
public void setLocation(String location) {
		this.location = location;
	}
public Student getStudent() {
		return student;
	}
public void setStudent(Student student) {
		this.student = student;
	}
	public User getUser() {
		return user;
	}
public void setUser(User user) {
		this.user = user;
	}
public Set<Student> getStudents() {
		return students;
	}

public void setStudents(Set<Student> students) {
		this.students = students;
	}
public static long getSerialversionuid() {
		return serialVersionUID;
	}

public void addStudent(Student student) {
student.setCollege(this);
this.getStudents().add(student);
	}	
}

