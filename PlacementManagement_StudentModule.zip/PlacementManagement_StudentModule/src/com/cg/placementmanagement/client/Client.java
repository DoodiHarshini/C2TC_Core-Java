package com.cg.placementmanagement.client;

import com.cg.placementmanagement.entity.Student;
import com.cg.placementmanagement.service.IStudentService;
import com.cg.placementmanagement.service.IStudentServiceImpl;

public class Client {

	public static void main(String[] args) {
	Student student = new Student();
	IStudentService service = new IStudentServiceImpl();
	
//Create
	student.setId(37);
	student.setName("Hasini");
	student.setCollege("SVCN");
	student.setRoll(5);
	student.setQualification("B.Tech");
	student.setCourse("ECE");
	student.setYear(2021);
	student.setCertificate("OD");
	student.setHallTicketNo(123437);
	service.addStudent(student);
	System.out.println("Data is added successfully");

  //Retrieve
	student=service.searchStudentById(36);
	System.out.println(student.getName());
	System.out.println(student.getHallTicketNo());
   // Update
	student=service.searchStudentById(37);
	student.setRoll(6);
	student.setCollege("GSTN");
	service.updateStudent(student);
	System.out.println("Update is successfully");
//Delete
	student=service.searchStudentById(37);
	service.deleteStudent(student);
	System.out.println("Delete is successfully");
	
	}
}