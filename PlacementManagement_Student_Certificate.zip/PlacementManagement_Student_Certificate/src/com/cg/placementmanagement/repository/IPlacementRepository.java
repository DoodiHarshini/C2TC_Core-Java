package com.cg.placementmanagement.repository;

import com.cg.placementmanagement.entity.Placement;

public interface IPlacementRepository {
	public Placement addPlacement(Placement placement);
   public Placement updatePlacement(Placement placement);
   public Placement searchPlacement(int id);
   
	public boolean cancelPlacement(String id); 
	public abstract void commitTransaction();
	public abstract void beginTransaction();
	
}
