package com.cg.placementmanagement.client;

import com.cg.placementmanagement.entity.Admin;
import com.cg.placementmanagement.entity.Certificate;
import com.cg.placementmanagement.entity.College;
import com.cg.placementmanagement.entity.Placement;
import com.cg.placementmanagement.entity.Student;
import com.cg.placementmanagement.entity.User;
import com.cg.placementmanagement.service.IStudentService;
import com.cg.placementmanagement.service.IStudentServiceImpl;

public class Client {

	public static void main(String[] args) {
	Student student = new Student();
	IStudentService service = new IStudentServiceImpl();

//Create
	student.setId(37);
	student.setName("Hasini");
	student.setRoll(5);
	student.setQualification("B.Tech");
	student.setCourse("ECE");
	student.setYear(2021);
	student.setHallTicketNo(123437);
	
	Certificate certificate =new Certificate();
	certificate.setId(37);
	certificate.setYear(2021);
	
	College college =new College();
	college.setId(37);
	college.setCollegeName("Sree Venkateswara College of Engineering");
	college.setLocation("Nellore");
	
	User user= new User();
	user.setId(37);
	user.setName("Hasini");
	user.setType("Convaction");
	
	Placement placement=new Placement();
	placement.setId(37);
	placement.setName("Hasini");
	placement.setDate(15-3-2022);
	placement.setQualification("B.Tech");
	placement.setYear(2021);
	
	Admin admin =new Admin();
	admin.setId(37);
	admin.setName("Hasini");
	admin.setPassword("@Hasini123");
	
	//OneToOne
	student.setCertificate(certificate);
	certificate.setStudent(student);
	//ManyToOne
		student.setCollege(college);
		
	//OneToOne
		user.setCollege(college);
		college.setUser(user);
	//ManyToOne
		placement.setCollege(college);
		//ManyToOne
		certificate.setCollege(college);
		//OneToOne
		user.setAdmin(admin);
		admin.setUser(user);
		service.addStudent(student);
		
System.out.println("Data is added successfully");

	
//  //Retrieve
//	student=service.searchStudentById(36);
//	System.out.println(student.getName());
//	System.out.println(student.getHallTicketNo());
//   // Update
//	student=service.searchStudentById(37);
//	student.setRoll(6);
//	student.setCollege("GSTN");
//	service.updateStudent(student);
//	System.out.println("Update is successfully");
////Delete
//	student=service.searchStudentById(37);
//	service.deleteStudent(student);
//	System.out.println("Delete is successfully");
//	
	}
}